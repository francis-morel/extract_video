opencv_version = "4.5.5.64"
contrib = False
headless = False
ci_build = True